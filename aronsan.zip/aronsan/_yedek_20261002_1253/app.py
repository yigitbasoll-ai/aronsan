import os
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'aronsan_gizli_anahtar'

UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def get_db_connection():
    conn = sqlite3.connect('aronsan.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.context_processor
def inject_user():
    if session.get('kullanici_id'):
        conn = get_db_connection()
        aktif = conn.execute("SELECT * FROM kullanicilar WHERE id = ?", (session['kullanici_id'],)).fetchone()
        okunmamis_bildirim = conn.execute("SELECT COUNT(*) FROM bildirimler WHERE kullanici_id = ? AND okundu = 0", (session['kullanici_id'],)).fetchone()[0]
        bildirimler_listesi = conn.execute("SELECT * FROM bildirimler WHERE kullanici_id = ? ORDER BY id DESC LIMIT 15", (session['kullanici_id'],)).fetchall()
        conn.close()
        return dict(aktif_kullanici=aktif, okunmamis_bildirim=okunmamis_bildirim, bildirimler_listesi=bildirimler_listesi)
    return dict(aktif_kullanici=None, okunmamis_bildirim=0, bildirimler_listesi=[])

@app.route('/')
def index():
    conn = get_db_connection()
    haberler = conn.execute('SELECT h.*, (SELECT COUNT(*) FROM haber_yorumlari WHERE haber_id = h.id) as yorum_sayisi FROM haberler h ORDER BY h.id DESC').fetchall()
    conn.close()
    return render_template('index.html', haberler=haberler)

@app.route('/projeler')
def projeler():
    conn = get_db_connection()
    projeler_listesi = conn.execute('SELECT * FROM projeler ORDER BY id DESC').fetchall()
    conn.close()
    return render_template('projeler.html', projeler=projeler_listesi)

@app.route('/ekibimiz')
def ekibimiz():
    conn = get_db_connection()
    try: personeller = conn.execute('SELECT * FROM ekip_uyeleri ORDER BY id ASC').fetchall()
    except sqlite3.OperationalError: personeller = [] 
    conn.close()
    return render_template('ekibimiz.html', personeller=personeller)

@app.route('/ekip/<int:id>')
def uye_detay(id):
    conn = get_db_connection()
    personel = conn.execute('SELECT * FROM ekip_uyeleri WHERE id = ?', (id,)).fetchone()
    conn.close()
    if not personel: return redirect(url_for('ekibimiz'))
    return render_template('uye_detay.html', personel=personel)

@app.route('/hakkimizda')
def hakkimizda(): return render_template('hakkimizda.html')

@app.route('/ayarlar', methods=['GET', 'POST'])
def ayarlar():
    if not session.get('kullanici_id'): return redirect(url_for('giris'))
    mesaj = None
    if request.method == 'POST':
        islem = request.form.get('islem')
        if islem == 'destek': mesaj = "Destek talebiniz başarıyla iletildi."
        elif islem == 'hesap_sil':
            conn = get_db_connection()
            conn.execute("DELETE FROM kullanicilar WHERE id = ?", (session['kullanici_id'],))
            conn.commit(); conn.close()
            session.clear()
            return redirect(url_for('index'))
    return render_template('ayarlar.html', mesaj=mesaj)

@app.route('/kayit', methods=['GET', 'POST'])
def kayit():
    if request.method == 'POST':
        conn = get_db_connection()
        conn.execute('INSERT INTO kullanicilar (ad_soyad, eposta, sifre, yetki) VALUES (?, ?, ?, ?)', (request.form['ad_soyad'], request.form['eposta'], request.form['sifre'], 'kullanici'))
        conn.commit(); conn.close()
        return redirect(url_for('giris'))
    return render_template('kayit.html')

@app.route('/giris', methods=['GET', 'POST'])
def giris():
    if request.method == 'POST':
        conn = get_db_connection()
        kullanici = conn.execute('SELECT * FROM kullanicilar WHERE eposta = ? AND sifre = ?', (request.form['eposta'], request.form['sifre'])).fetchone()
        conn.close()
        if kullanici:
            session['kullanici_id'] = kullanici['id']
            return redirect(url_for('index'))
        return redirect(url_for('giris'))
    return render_template('giris.html')

@app.route('/personel-giris', methods=['GET', 'POST'])
def personel_giris():
    if request.method == 'POST':
        conn = get_db_connection()
        personel = conn.execute("SELECT * FROM kullanicilar WHERE eposta = ? AND sifre = ? AND yetki = 'personel'", (request.form['eposta'], request.form['sifre'])).fetchone()
        conn.close()
        if personel:
            session['kullanici_id'] = personel['id']
            session['yetki'] = personel['yetki']
            return redirect(url_for('admin'))
        return redirect(url_for('personel_giris'))
    return render_template('personel_giris.html')

@app.route('/cikis')
def cikis(): session.clear(); return redirect(url_for('index'))

@app.route('/hesap-ayarlari', methods=['GET', 'POST'])
def hesap_ayarlari():
    if not session.get('kullanici_id'): return redirect(url_for('giris'))
    mesaj, conn = None, get_db_connection()
    if request.method == 'POST':
        dosya = request.files.get('profil_gorsel')
        yeni_foto = request.form.get('mevcut_foto')
        if dosya and dosya.filename != '':
            filename = secure_filename(dosya.filename)
            dosya.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            yeni_foto = '/static/uploads/' + filename
        conn.execute("UPDATE kullanicilar SET ad_soyad = ?, sifre = ?, biyografi = ?, profil_fotografi = ? WHERE id = ?", (request.form['ad_soyad'], request.form['sifre'], request.form.get('biyografi', ''), yeni_foto, session['kullanici_id']))
        conn.commit(); mesaj = "Hesap güncellendi."
    kisi = conn.execute("SELECT * FROM kullanicilar WHERE id = ?", (session['kullanici_id'],)).fetchone()
    conn.close()
    return render_template('hesap_ayarlari.html', kisi=kisi, mesaj=mesaj)

@app.route('/api/bildirimleri_okudum', methods=['POST'])
def bildirimleri_okudum():
    if not session.get('kullanici_id'): return jsonify({'status': 'error'})
    conn = get_db_connection()
    conn.execute("UPDATE bildirimler SET okundu = 1 WHERE kullanici_id = ?", (session['kullanici_id'],))
    conn.commit(); conn.close()
    return jsonify({'status': 'success'})

@app.route('/api/bildirim/sil/<int:id>', methods=['POST'])
def bildirim_sil(id):
    if not session.get('kullanici_id'): return jsonify({'status': 'error'})
    conn = get_db_connection()
    conn.execute("DELETE FROM bildirimler WHERE id = ? AND kullanici_id = ?", (id, session['kullanici_id']))
    conn.commit(); conn.close()
    return jsonify({'status': 'success'})

@app.route('/api/bildirim/sil_tumu', methods=['POST'])
def bildirim_sil_tumu():
    if not session.get('kullanici_id'): return jsonify({'status': 'error'})
    conn = get_db_connection()
    conn.execute("DELETE FROM bildirimler WHERE kullanici_id = ?", (session['kullanici_id'],))
    conn.commit(); conn.close()
    return jsonify({'status': 'success'})

@app.route('/api/arama')
def api_arama():
    q = request.args.get('q', '').strip()
    if not q: return jsonify({'kisiler': [], 'haberler': []})
    conn = get_db_connection()
    haberler = conn.execute("SELECT id, baslik FROM haberler WHERE baslik LIKE ? OR icerik LIKE ? ORDER BY id DESC LIMIT 5", ('%'+q+'%', '%'+q+'%')).fetchall()
    kisiler = conn.execute("SELECT id, ad_soyad, profil_fotografi, mavi_tik FROM kullanicilar WHERE ad_soyad LIKE ? ORDER BY id DESC LIMIT 5", ('%'+q+'%',)).fetchall()
    conn.close()
    return jsonify({'kisiler': [dict(k) for k in kisiler], 'haberler': [dict(h) for h in haberler]})

@app.route('/api/takip/<int:id>', methods=['POST'])
def api_takip(id):
    if not session.get('kullanici_id'): return jsonify({'status': 'error'})
    ben = session['kullanici_id']
    if ben == id: return jsonify({'status': 'error'})
    conn = get_db_connection()
    benim_bilgi = conn.execute("SELECT ad_soyad FROM kullanicilar WHERE id = ?", (ben,)).fetchone()
    kontrol = conn.execute("SELECT * FROM takipciler WHERE takip_eden_id = ? AND takip_edilen_id = ?", (ben, id)).fetchone()
    if kontrol:
        conn.execute("DELETE FROM takipciler WHERE takip_eden_id = ? AND takip_edilen_id = ?", (ben, id))
        durum = 'takipten_cikildi'
    else:
        conn.execute("INSERT INTO takipciler (takip_eden_id, takip_edilen_id) VALUES (?, ?)", (ben, id))
        durum = 'takip_edildi'
        conn.execute("INSERT INTO bildirimler (kullanici_id, icerik) VALUES (?, ?)", (id, f"{benim_bilgi['ad_soyad']} seni takip etmeye başladı."))
    takipci_sayisi = conn.execute("SELECT COUNT(*) FROM takipciler WHERE takip_edilen_id = ?", (id,)).fetchone()[0]
    conn.commit(); conn.close()
    return jsonify({'status': 'success', 'durum': durum, 'takipci_sayisi': takipci_sayisi})

@app.route('/api/haber/<int:id>/begen', methods=['POST'])
def api_haber_begen(id):
    if not session.get('kullanici_id'): return jsonify({'status': 'error'})
    ben = session['kullanici_id']
    conn = get_db_connection()
    kontrol = conn.execute("SELECT * FROM haber_begenileri WHERE haber_id = ? AND kullanici_id = ?", (id, ben)).fetchone()
    if kontrol:
        conn.execute("DELETE FROM haber_begenileri WHERE haber_id = ? AND kullanici_id = ?", (id, ben))
        conn.execute("UPDATE haberler SET begeni = begeni - 1 WHERE id = ?", (id,))
    else:
        conn.execute("INSERT INTO haber_begenileri (haber_id, kullanici_id) VALUES (?, ?)", (id, ben))
        conn.execute("UPDATE haberler SET begeni = begeni + 1 WHERE id = ?", (id,))
    yeni_begeni = conn.execute("SELECT begeni FROM haberler WHERE id = ?", (id,)).fetchone()[0]
    conn.commit(); conn.close()
    return jsonify({'status': 'success', 'begeni': yeni_begeni})

@app.route('/api/haber/<int:id>/kaydet', methods=['POST'])
def api_haber_kaydet(id):
    if not session.get('kullanici_id'): return jsonify({'status': 'error'})
    ben = session['kullanici_id']
    conn = get_db_connection()
    kontrol = conn.execute("SELECT * FROM haber_kayitlari WHERE haber_id = ? AND kullanici_id = ?", (id, ben)).fetchone()
    if kontrol:
        conn.execute("DELETE FROM haber_kayitlari WHERE haber_id = ? AND kullanici_id = ?", (id, ben))
        durum = 'cikarildi'
    else:
        conn.execute("INSERT INTO haber_kayitlari (haber_id, kullanici_id) VALUES (?, ?)", (id, ben))
        durum = 'kaydedildi'
    conn.commit(); conn.close()
    return jsonify({'status': 'success', 'durum': durum})

@app.route('/api/mesaj_gonder', methods=['POST'])
def api_mesaj_gonder():
    if not session.get('kullanici_id'): return jsonify({'status': 'error'})
    data = request.get_json()
    ben = session['kullanici_id']
    alici = data.get('alici_id')
    icerik = data.get('icerik')
    conn = get_db_connection()
    benim_bilgi = conn.execute("SELECT ad_soyad FROM kullanicilar WHERE id = ?", (ben,)).fetchone()
    conn.execute("INSERT INTO mesajlar (gonderen_id, alici_id, icerik, okundu) VALUES (?, ?, ?, 0)", (ben, alici, icerik))
    conn.execute("INSERT INTO bildirimler (kullanici_id, icerik) VALUES (?, ?)", (alici, f"{benim_bilgi['ad_soyad']} sana mesaj gönderdi."))
    conn.commit(); conn.close()
    return jsonify({'status': 'success'})

@app.route('/api/sohbet_ayar', methods=['POST'])
def sohbet_ayar():
    if not session.get('kullanici_id'): return jsonify({'status': 'error'})
    data = request.get_json()
    alici_id = data.get('alici_id')
    tema = data.get('tema')
    takma_ad = data.get('takma_ad')
    ben = session['kullanici_id']
    
    conn = get_db_connection()
    mevcut = conn.execute("SELECT * FROM sohbet_ayarlari WHERE kullanici_id = ? AND hedef_id = ?", (ben, alici_id)).fetchone()
    if mevcut:
        conn.execute("UPDATE sohbet_ayarlari SET tema = ?, takma_ad = ? WHERE kullanici_id = ? AND hedef_id = ?", (tema, takma_ad, ben, alici_id))
    else:
        conn.execute("INSERT INTO sohbet_ayarlari (kullanici_id, hedef_id, tema, takma_ad) VALUES (?, ?, ?, ?)", (ben, alici_id, tema, takma_ad))
    conn.commit(); conn.close()
    return jsonify({'status': 'success'})

@app.route('/profil/<int:id>')
def profil(id):
    conn = get_db_connection()
    kisi = conn.execute("SELECT * FROM kullanicilar WHERE id = ?", (id,)).fetchone()
    if not kisi: conn.close(); return redirect(url_for('index'))
    takipci_sayisi = conn.execute("SELECT COUNT(*) FROM takipciler WHERE takip_edilen_id = ?", (id,)).fetchone()[0]
    takip_edilen_sayisi = conn.execute("SELECT COUNT(*) FROM takipciler WHERE takip_eden_id = ?", (id,)).fetchone()[0]
    takip_durumu = False
    if session.get('kullanici_id') and conn.execute("SELECT * FROM takipciler WHERE takip_eden_id = ? AND takip_edilen_id = ?", (session['kullanici_id'], id)).fetchone():
        takip_durumu = True
    gonderiler = conn.execute("SELECT g.*, k.ad_soyad as yazar_ad, k.profil_fotografi as yazar_foto, k.mavi_tik as yazar_tik FROM gonderiler g JOIN kullanicilar k ON g.kullanici_id = k.id WHERE g.kullanici_id = ? ORDER BY g.id DESC", (id,)).fetchall()
    conn.close()
    return render_template('profil.html', kisi=kisi, takipci_sayisi=takipci_sayisi, takip_edilen_sayisi=takip_edilen_sayisi, takip_durumu=takip_durumu, gonderiler=gonderiler)

@app.route('/gonderi-paylas', methods=['POST'])
def gonderi_paylas():
    if not session.get('kullanici_id'): return redirect(url_for('giris'))
    icerik = request.form.get('icerik')
    dosya = request.files.get('gorsel')
    gorsel_url = ''
    if dosya and dosya.filename != '':
        filename = secure_filename(dosya.filename)
        dosya.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        gorsel_url = '/static/uploads/' + filename
    if icerik:
        conn = get_db_connection()
        conn.execute('INSERT INTO gonderiler (kullanici_id, icerik, gorsel_url) VALUES (?, ?, ?)', (session['kullanici_id'], icerik, gorsel_url))
        conn.commit(); conn.close()
    return redirect(request.referrer or url_for('profil', id=session['kullanici_id']))

@app.route('/gonderi/<int:id>/sil')
def gonderi_sil(id):
    if session.get('kullanici_id'):
        conn = get_db_connection()
        conn.execute("DELETE FROM gonderiler WHERE id = ? AND kullanici_id = ?", (id, session['kullanici_id']))
        conn.commit(); conn.close()
    return redirect(request.referrer or url_for('profil', id=session['kullanici_id']))

@app.route('/haber/<int:id>', methods=['GET', 'POST'])
def haber_detay(id):
    conn = get_db_connection()
    if request.method == 'GET': conn.execute("UPDATE haberler SET goruntulenme = goruntulenme + 1 WHERE id = ?", (id,)); conn.commit()
    if request.method == 'POST' and session.get('kullanici_id'):
        ben = session['kullanici_id']
        aktif = conn.execute("SELECT ad_soyad FROM kullanicilar WHERE id = ?", (ben,)).fetchone()
        conn.execute("INSERT INTO haber_yorumlari (haber_id, kullanici_ad, yorum) VALUES (?, ?, ?)", (id, aktif['ad_soyad'], request.form['yorum']))
        conn.commit(); return redirect(url_for('haber_detay', id=id))
    haber = conn.execute("SELECT * FROM haberler WHERE id = ?", (id,)).fetchone()
    yorumlar = conn.execute("SELECT y.*, k.mavi_tik FROM haber_yorumlari y LEFT JOIN kullanicilar k ON y.kullanici_ad = k.ad_soyad WHERE y.haber_id = ? ORDER BY y.id DESC", (id,)).fetchall()
    begenildi_mi = False
    kaydedildi_mi = False
    if session.get('kullanici_id'):
        ben = session['kullanici_id']
        if conn.execute("SELECT * FROM haber_begenileri WHERE haber_id = ? AND kullanici_id = ?", (id, ben)).fetchone(): begenildi_mi = True
        if conn.execute("SELECT * FROM haber_kayitlari WHERE haber_id = ? AND kullanici_id = ?", (id, ben)).fetchone(): kaydedildi_mi = True
    conn.close()
    return render_template('haber_detay.html', haber=haber, yorumlar=yorumlar, begenildi_mi=begenildi_mi, kaydedildi_mi=kaydedildi_mi)

@app.route('/mesajlar')
@app.route('/mesajlar/<int:alici_id>')
def mesaj_paneli(alici_id=None):
    if not session.get('kullanici_id'): return redirect(url_for('giris'))
    ben = session['kullanici_id']
    conn = get_db_connection()
    
    # DM listesindeki kişileri çekerken takma adı da join ile çekiyoruz
    kisiler = conn.execute('''
        SELECT k.id, k.ad_soyad, k.profil_fotografi, k.mavi_tik, 
        (SELECT takma_ad FROM sohbet_ayarlari WHERE kullanici_id = ? AND hedef_id = k.id) as ozel_ad 
        FROM kullanicilar k WHERE k.id != ? ORDER BY k.id DESC
    ''', (ben, ben)).fetchall()
    
    secili_kisi, sohbet = None, []
    aktif_tema = "default"
    aktif_takma_ad = ""
    
    if alici_id:
        secili_kisi = conn.execute("SELECT id, ad_soyad, profil_fotografi, mavi_tik FROM kullanicilar WHERE id = ?", (alici_id,)).fetchone()
        conn.execute("UPDATE mesajlar SET okundu = 1 WHERE gonderen_id = ? AND alici_id = ?", (alici_id, ben))
        conn.commit()
        sohbet = conn.execute('''SELECT * FROM mesajlar WHERE (gonderen_id = ? AND alici_id = ?) OR (gonderen_id = ? AND alici_id = ?) ORDER BY tarih ASC''', (ben, alici_id, alici_id, ben)).fetchall()
        
        ayar = conn.execute("SELECT * FROM sohbet_ayarlari WHERE kullanici_id = ? AND hedef_id = ?", (ben, alici_id)).fetchone()
        if ayar:
            aktif_tema = ayar['tema'] or "default"
            aktif_takma_ad = ayar['takma_ad'] or ""
            
    conn.close()
    return render_template('mesaj_paneli.html', kisiler=kisiler, secili_kisi=secili_kisi, sohbet=sohbet, aktif_tema=aktif_tema, aktif_takma_ad=aktif_takma_ad)

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if session.get('yetki') != 'personel': return redirect(url_for('index'))
    mesaj = None
    if request.method == 'POST' and 'kullanici_id_duzenle' in request.form:
        k_id = request.form['kullanici_id_duzenle']
        yeni_yetki = request.form['yetki']
        mavi_tik = 1 if 'mavi_tik' in request.form else 0
        conn = get_db_connection()
        conn.execute("UPDATE kullanicilar SET yetki = ?, mavi_tik = ? WHERE id = ?", (yeni_yetki, mavi_tik, k_id))
        conn.commit(); conn.close()
        mesaj = f"Kullanıcı ID {k_id} güncellendi!"
    return render_template('admin.html', mesaj=mesaj)
    
@app.route('/admin/proje-ekle', methods=['GET', 'POST'])
def proje_ekle():
    if session.get('yetki') != 'personel': return redirect(url_for('index'))
    if request.method == 'POST':
        conn = get_db_connection()
        conn.execute('INSERT INTO projeler (baslik, icerik, gorsel_url) VALUES (?, ?, ?)', (request.form['baslik'], request.form['icerik'], request.form['gorsel_url']))
        conn.commit(); conn.close(); return redirect(url_for('admin'))
    return render_template('proje_ekle.html')

@app.route('/admin/haber-ekle', methods=['GET', 'POST'])
def haber_ekle():
    if session.get('yetki') != 'personel': return redirect(url_for('index'))
    if request.method == 'POST':
        conn = get_db_connection()
        conn.execute('INSERT INTO haberler (baslik, icerik, firma_adi, gorsel_url) VALUES (?, ?, ?, ?)', (request.form['baslik'], request.form['icerik'], request.form['firma_adi'], request.form['gorsel_url']))
        conn.commit(); conn.close(); return redirect(url_for('admin'))
    return render_template('haber_ekle.html')

if __name__ == '__main__':
    conn = get_db_connection()
    try: conn.execute("ALTER TABLE kullanicilar ADD COLUMN mavi_tik INTEGER DEFAULT 0")
    except: pass
    try: conn.execute("ALTER TABLE mesajlar ADD COLUMN okundu INTEGER DEFAULT 0")
    except: pass
    conn.execute('''CREATE TABLE IF NOT EXISTS haber_kayitlari (id INTEGER PRIMARY KEY AUTOINCREMENT, haber_id INTEGER NOT NULL, kullanici_id INTEGER NOT NULL)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS bildirimler (id INTEGER PRIMARY KEY AUTOINCREMENT, kullanici_id INTEGER NOT NULL, icerik TEXT NOT NULL, okundu INTEGER DEFAULT 0, tarih TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS sohbet_ayarlari (id INTEGER PRIMARY KEY AUTOINCREMENT, kullanici_id INTEGER NOT NULL, hedef_id INTEGER NOT NULL, tema TEXT, takma_ad TEXT)''')
    conn.commit(); conn.close()
    app.run(debug=True, port=5000)